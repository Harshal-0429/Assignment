USE online_shopping;

SELECT a.retail_price, a.discounted_price, a.product_name, f.retail_price, f.discounted_price , f.ï»¿product_name
FROM amazon as a INNER JOIN flipkart as f
ON a.product_name = f.ï»¿product_name
WHERE a.product_name='NURIDE CANVAS SHOES';